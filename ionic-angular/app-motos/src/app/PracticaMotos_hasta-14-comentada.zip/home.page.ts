import { Component } from '@angular/core';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  public motos: [];
  public marca: string;

  constructor(private router: Router, private route: ActivatedRoute) {
    this.router.onSameUrlNavigation = 'reload'; //Este atributo del router hace que cuando navegas a la misma ruta se recargue la pagina
                                                // y se ejecute el ngOnInit para actualizar la marca que envias por parametro
    this.marca="Todas";
  }

  ngOnInit() {
    //Aqui meto lo que se ejecuta al iniciar la pagina
    this.route.queryParams.subscribe(params => { 
      //la marca que hemos pasado por ruta desde component
      if (params.marca) {
        this.marca = params.marca;
        this.getJson();
      }
    });
  }


  async getJson() {
    
    let url="https://motos.puigverd.org/motos";
    if(this.marca!="Todas"){
      url="https://motos.puigverd.org/motos?marca=" + this.marca;
    }
     const respuesta = await fetch(url, {
      "method": "GET",
      "headers": {}
    });
    this.motos = await respuesta.json();
  }

  async seleccionar(detalle: string[]) {
    let navigationExtras: NavigationExtras = {
      state: {
        parametros: detalle,
      }
    };
    this.router.navigate(['detalle'], navigationExtras);
  }
 

  //Esto es lo que quieres que se ejecute cuando vienes de otra vista
  // por ejemplo cuando eleiminamos algo hacemos el getJson para obtener el listado actualizado
  ionViewWillEnter(){
    this.getJson();
  }
}



