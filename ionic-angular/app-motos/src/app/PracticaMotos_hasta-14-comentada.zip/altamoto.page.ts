import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-altamoto',
  templateUrl: './altamoto.page.html',
  styleUrls: ['./altamoto.page.scss'],
})
export class AltamotoPage implements OnInit {
  //tienes que crear los atributos de la clase
  inputMarca:string;
  inputModelo:string;
  inputYear:number;
  inputPrecio:number;

  constructor(private router: Router,) { }

  //Funcion para subir la moto
  subirMoto(){

    //este es el cierpo de la consulta que tambien puedes ponerlo directamente dentro del fetch pero me gusta mas asi
    let moto={
      "marca": this.inputMarca,
      "modelo": this.inputModelo,
      "year": this.inputYear,
      "foto": "http://motos-b60.kxcdn.com/sites/default/files/ducati-multistrada-1260-2018.jpg",
      "precio": this.inputPrecio
    }

    fetch("https://motos.puigverd.org/moto", {
  "method": "POST",
  "headers": {
    "content-type": "application/json"
  },
  "body": JSON.stringify(moto) //aqui le pasas el cuerpo osea la moto
})
.then(response => {
  console.log(response);
  this.router.navigateByUrl('/home'); // y si todo va bien te redirecciona al home
})
.catch(err => {
  console.log(err);
});
  }

  ngOnInit() {
  }

}
