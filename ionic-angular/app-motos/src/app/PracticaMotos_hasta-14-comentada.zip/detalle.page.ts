import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.page.html',
  styleUrls: ['./detalle.page.scss'],
})

export class DetallePage implements OnInit {

  public detalle :any;
  constructor(private route: ActivatedRoute,
               private router: Router,
               public alertController: AlertController) { 
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.detalle = this.router.getCurrentNavigation().extras.state.parametros;
      }
    });
  }


  //Funcion que crea un alert con dos botones uno que cancela y otro que confirma y ejecuta la funcion borrarMoto
  //Esta funcion es la que ejecutampos en el boton de la vista y le pasamos el id de la moto
  async borrarMotoConfirm(idMoto) {
    const alert = await this.alertController.create({
      header: 'Cuidado!',
      message: 'Estas segura que quieres borrar esta moto?',
      buttons: [
        //boton 1 
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          //esto es lo que hace el boton
          handler: (blah) => {
            console.log('Confirm Cancel: blah'+idMoto);
          }
        },
        
        //boton 2
        {
          text: 'Confirmar',
          //Esto es lo que hace el boton en nuestro caso llamar a la funcion borrarMoto que esta mas abajo y le pasa el idMoto
          handler: () => {
            this.borrarMoto(idMoto);

          }
        }
      ]
    });
    //y muestras el alert
    await alert.present();
  }

  //Funcion que hace una consulta DELETE pasando el idMoto
  async borrarMoto(idMoto) {
    const url = "https://motos.puigverd.org/moto/" + idMoto;
    fetch(url, {
      "method": "DELETE"
    })
    .then(response => {
        this.router.navigateByUrl('/home'); // si todo va bien te redirige a home
      });
  }

  ngOnInit() {
  }

}
