import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  marcas : any;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
  ) {
    this.getMarcas();
    this.initializeApp();

  }
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }


  //Esta es mi manera de obtener las marcas seguro que puedes hacerlo de otra manera pero ya sabes que me encantan los arrays
   async getMarcas(){
    this.marcas = 

    await fetch('https://motos.puigverd.org/motos') //consulto todas las motos
    .then(function(response) {
      return response.json();
    })

    .then(function(motos) {
      var marcasTodas=[];
      motos.forEach(element => {    // Guardo todas las marcas en un array
        marcasTodas.push(element.marca)
      });
      return marcasTodas.filter((n, i) => marcasTodas.indexOf(n) === i); // filtro para borrar las repetidas
    })
    //en este punto ya puedes hacer return 


    .then(function(marcasUnicas) { //esto es algo extra que hago para guardar la marca y la imagen en forma de json
      var marcasJson = Array();   //pero es inutil si no consigo que funcione la funcion que esta comentada abajo
      marcasJson.push({nombre : "Todas",imagen :"Todas.png"})
      marcasUnicas.forEach(element => {
        marcasJson.push({nombre : element,imagen :element+".png"})
      });
      console.log(marcasJson);
      return marcasJson; //y retornas las marcas 
    });

    }

      //WORK IN PROGRESS
    // getImagen(path:string){
    //   fetch("../assets/"+path+".png").then(function(response) {
    //     if(response.ok) {
    //       response.blob().then(function(miBlob) {
    //         var objectURL = URL.createObjectURL(miBlob);
    //         path = objectURL;
    //         return path;
    //       });
    //     } else {
    //       path ="";
    //       return path;
    //     }
    //   })
    //   .catch(function(error) {
    //     path ="";
    //     return path;
    //   });
    //   return path;
    // }
    
  
 }

